<!DOCTYPE html>
<html lang="en" ng-app="Foodees">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Foodees">
    <meta name="google-site-verification" content="lTvHnpyuwvPWbpD1M5iVPn88916nXrSdx43wSSjdOz4">
    <title>Foodees Tiffin Service - Better Food. Not Better Marketing.</title>
    <meta name="description" content="Foodees Tiffin Service provides veg and non-veg Lunch &amp; Dinner tiffins starting at just Rs. 70. Home-cooked ✓Healthy ✓Hygienic Food ✓Customized Meal Plans. Salad, Roasted, Pasta, Burger, Sandwich and Indian Tiffin Services in Mumbai.  Start your Tiffin Service Now.">
    <meta name="keywords" content="tiffin service,tiffin services,tiffin services mumbai,tiffin service mumbai,tiffin service in mumbai,tiffin services in mumbai,online tiffin service,lunch box service in mumbai,home made tiffin service in mumbai,healthy tiffin service mumbai,dabbawala mumbai,best tiffin service in mumbai,dabbawala service,mumbai tiffin service,non veg tiffin service in mumbai,daily tiffin service in mumbai,healthy meal tiffin service mumbai,lunch service in mumbai,tiffin service in mumbai home made food,dabba service in mumbai,information about tiffin service,tiffin services near me,veg tiffin service in mumbai,non veg tiffin service in mumbai,mumbai tiffin,zero oil tiffins in mumbai,zero oil tiffin service in mumbai,mumbai dabbawala,executive tiffin services in mumbai,marwari tiffin service in mumbai,jain tiffin service in mumbai,south indian tiffin service in mumbai,north indian tiffin service in mumbai,foodies tiffin service,foodees tiffin service,monthly tiffin service mumbai,food service in mumbai,gourmet tiffin services,corporate meals mumbai,mumbai healthy tiffin,ghar ka khana,catering tiffin services mumbai">
    <link rel="canonical" href="http://www.foodees.in/">
    <meta property="og:locale" content="en_US">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Foodees Tiffin Service | Veg Tiffin Service in Mumbai for Lunch &amp; Dinner">
    <meta property="og:description" content="Foodees Tiffin Service provides veg and non-veg Lunch &amp; Dinner tiffins starting at just Rs. 70. Home-cooked ✓Healthy ✓Hygienic Food ✓Customized Meal Plans. Salad, Roasted, Pasta, Burger, Sandwich and Indian Tiffin Services in Mumbai.  Start your Tiffin Service Now.">
    <meta property="og:url" content="http://www.foodees.in/">
    <meta property="og:site_name" content="Foodees Tiffin Service">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:description" content="Foodees Tiffin Service provides veg and non-veg Lunch &amp; Dinner tiffins starting at just Rs. 70. Home-cooked ✓Healthy ✓Hygienic Food ✓Customized Meal Plans. Salad, Roasted, Pasta, Burger, Sandwich and Indian Tiffin Services in Mumbai.  Start your Tiffin Service Now.">
    <meta name="twitter:title" content="Foodees Tiffin Service | Veg Tiffin Service in Mumbai for Lunch &amp; Dinner">
    <!-- Bootstrap Core CSS-->
    <link href="/vendor/bootstrap/dist/css/bootstrap.css" rel="stylesheet">
    <link href="/vendor/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="/vendor/ng-sticky-element/dist/ng-sticky-element.min.css" rel="stylesheet">
    <link href="https://rawgit.com/dbtek/angular-aside/master/dist/css/angular-aside.css" rel="stylesheet">
    <link href="/vendor/please-wait/build/please-wait.css" rel="stylesheet">
    <!-- Custom CSS-->
    <link href="/css/style.css" rel="stylesheet">
  </head>
  <body>
    <div class="overlay"></div>
    <div class="container">
      <div class="row page">
        <div ui-view="header"></div>
        <div ui-view="container"></div>
        <div ui-view="footer"></div>
      </div>
    </div>
    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
      ga('create', 'UA-38553874-1', 'auto');
      ga('send', 'pageview');
      
    </script>
    <script type="text/javascript">
      var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
      (function(){
      var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
      s1.async=true;
      s1.src='https://embed.tawk.to/5659cc265ced5f6455f466ce/default';
      s1.charset='UTF-8';
      s1.setAttribute('crossorigin','*');
      s0.parentNode.insertBefore(s1,s0);
      })();
      
    </script>
    <!-- Hotjar Tracking Code for foodees.in-->
    <script>
      (function(h,o,t,j,a,r){
      h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
      h._hjSettings={hjid:428555,hjsv:5};
      a=o.getElementsByTagName('head')[0];
      r=o.createElement('script');r.async=1;
      r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
      a.appendChild(r);
      })(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');
      
    </script>
    <script type="text/javascript" src="/vendor/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="/vendor/tether/dist/js/tether.js"></script>
    <script type="text/javascript" src="/vendor/bootstrap/dist/js/bootstrap.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/0.2.0/Chart.min.js"></script>
    <!-- Third-party Libraries-->
    <script src="/vendor/angular.js"></script>
    <script src="/vendor/angular-animate.js"></script>
    <script src="/vendor/angular-messages.js"></script>
    <script src="/vendor/angular-resource.js"></script>
    <script src="/vendor/angular-sanitize.js"></script>
    <script src="/vendor/angular-ui-router.js"></script>
    <script src="/vendor/angular-toastr.tpls.js"></script>
    <script src="/vendor/satellizer.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/angular-ui-bootstrap/2.3.1/ui-bootstrap-tpls.min.js"></script>
    <script src="/vendor/moment.min.js"></script>
    <script src="/vendor/angular-moment/angular-moment.js"></script>
    <script src="/vendor/ng-sticky-element/dist/ng-sticky-element.min.js"></script>
    <script src="/vendor/angular-aside/dist/js/angular-aside.js"></script>
    <script src="/vendor/please-wait/build/please-wait.js"></script>
    <script type="text/javascript">
      window.loading_screen = window.pleaseWait({
      logo: "/images/loader.gif",
      backgroundColor: '#fff',
      loadingHtml: ""
      });
      setTimeout(function(){
      window.loading_screen.finish();
      },6000)
      
      
    </script>
    <!-- Application Code-->
    <!--script(src='/app.min.js')-->
    <script src="/app.js"></script>
    <!--script(src='/js/directives/passwordStrength.js')-->
    <!--script(src='/js/directives/passwordMatch.js')-->
    <!--script(src='/js/directives/toggleClass.js')-->
    <script src="/js/directives/aside.js"></script>
    <!--script(src='/js/controllers/home.js')-->
    <!--script(src='/js/controllers/dashboard.js')-->
    <!--script(src='/js/controllers/login.js')-->
    <!--script(src='/js/controllers/admin.js')-->
    <!--script(src='/js/controllers/press.js')-->
    <!--script(src='/js/controllers/recharge.js')-->
    <!--script(src='/js/controllers/address.js')-->
    <!--script(src='/js/controllers/tiffinservice.js')-->
    <!--script(src='/js/controllers/signup.js')-->
    <!--script(src='/js/controllers/logout.js')-->
    <!--script(src='/js/controllers/profile.js')-->
    <!--script(src='/js/controllers/orders.js')-->
    <!--script(src='/js/controllers/payments.js')-->
    <!--script(src='/js/controllers/cart.js')-->
    <!--script(src='/js/controllers/header.js')-->
    <!--script(src='/js/controllers/footer.js')-->
    <!--script(src='/js/services/account.js')-->
    <!--script(src='/js/services/address.js')-->
    <!--script(src='/js/services/order.js')-->
    <!--script(src='/js/services/transaction.js')-->
    <!--script(src='/js/services/menu.js')-->
    <!--script(src='/js/services/item.js')-->
    <!--script(src='/js/services/meal.js')-->
    <!--script(src='/js/services/scroll.js')-->
    <script src="templates.js"></script>
  </body>
</html>